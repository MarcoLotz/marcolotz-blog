################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
O_SRCS += \
../debug/src/core_cm3.o \
../debug/src/system_LPC13xx.o 


# Each subdirectory must supply rules for building sources it contributes


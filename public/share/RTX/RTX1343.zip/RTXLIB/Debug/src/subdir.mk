################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/HAL_CM.c \
../src/rt_CMSIS.c \
../src/rt_Event.c \
../src/rt_List.c \
../src/rt_Mailbox.c \
../src/rt_MemBox.c \
../src/rt_Memory.c \
../src/rt_Mutex.c \
../src/rt_Robin.c \
../src/rt_Semaphore.c \
../src/rt_System.c \
../src/rt_Task.c \
../src/rt_Time.c \
../src/rt_Timer.c 

OBJS += \
./src/HAL_CM.o \
./src/rt_CMSIS.o \
./src/rt_Event.o \
./src/rt_List.o \
./src/rt_Mailbox.o \
./src/rt_MemBox.o \
./src/rt_Memory.o \
./src/rt_Mutex.o \
./src/rt_Robin.o \
./src/rt_Semaphore.o \
./src/rt_System.o \
./src/rt_Task.o \
./src/rt_Time.o \
./src/rt_Timer.o 

C_DEPS += \
./src/HAL_CM.d \
./src/rt_CMSIS.d \
./src/rt_Event.d \
./src/rt_List.d \
./src/rt_Mailbox.d \
./src/rt_MemBox.d \
./src/rt_Memory.d \
./src/rt_Mutex.d \
./src/rt_Robin.d \
./src/rt_Semaphore.d \
./src/rt_System.d \
./src/rt_Task.d \
./src/rt_Time.d \
./src/rt_Timer.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -D__CMSIS_RTOS -D__CORTEX_M3 -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p00_LPC13xx -D__LPC13XX__ -I"/home/prometheus/Desktop/Renaux/RTXLIB/inc" -I"/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc" -O0 -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



src/light.d: ../src/light.c \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/mcu_regs.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/lpc13xx.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cm3.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmInstr.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmFunc.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/system_LPC13xx.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/type.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/i2c.h \
 /home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/light.h

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/mcu_regs.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/lpc13xx.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cm3.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmInstr.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmFunc.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/system_LPC13xx.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/type.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/i2c.h:

/home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/light.h:

src/font5x7.d: ../src/font5x7.c \
 /home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/font_macro.h

/home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/font_macro.h:

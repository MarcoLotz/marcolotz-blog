################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lLib_MCU -lCMSISv2p00_LPC13xx -lRTXLIB -lLib_EaBaseBoard


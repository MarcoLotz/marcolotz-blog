src/main.d: ../src/main.c \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/lpc13xx.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cm3.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmInstr.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmFunc.h \
 /home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/system_LPC13xx.h \
 /home/prometheus/Desktop/Renaux/RTXLIB/inc/cmsis_os.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/uart.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/i2c.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/gpio.h \
 /home/prometheus/Desktop/Renaux/Lib_MCU/inc/ssp.h \
 /home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/oled.h

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/lpc13xx.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cm3.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmInstr.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/core_cmFunc.h:

/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc/system_LPC13xx.h:

/home/prometheus/Desktop/Renaux/RTXLIB/inc/cmsis_os.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/uart.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/i2c.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/gpio.h:

/home/prometheus/Desktop/Renaux/Lib_MCU/inc/ssp.h:

/home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc/oled.h:

src/RTX_Conf_CM.d: ../src/RTX_Conf_CM.c \
 /home/prometheus/Desktop/Renaux/RTXLIB/inc/cmsis_os.h \
 /home/prometheus/Desktop/Renaux/RTXLIB/inc/RTX_CM_lib.h

/home/prometheus/Desktop/Renaux/RTXLIB/inc/cmsis_os.h:

/home/prometheus/Desktop/Renaux/RTXLIB/inc/RTX_CM_lib.h:

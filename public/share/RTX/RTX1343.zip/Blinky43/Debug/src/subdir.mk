################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/RTX_Conf_CM.c \
../src/cr_startup_lpc13xx.c \
../src/crp.c \
../src/main.c \
../src/system_ARMCM3.c 

OBJS += \
./src/RTX_Conf_CM.o \
./src/cr_startup_lpc13xx.o \
./src/crp.o \
./src/main.o \
./src/system_ARMCM3.o 

C_DEPS += \
./src/RTX_Conf_CM.d \
./src/cr_startup_lpc13xx.d \
./src/crp.d \
./src/main.d \
./src/system_ARMCM3.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p00_LPC13xx -D__LPC13XX__ -I"/home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc" -I"/home/prometheus/Desktop/Renaux/Lib_MCU/inc" -I"/home/prometheus/Desktop/Renaux/RTXLIB/inc" -I"/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc" -O0 -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/cr_startup_lpc13xx.o: ../src/cr_startup_lpc13xx.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p00_LPC13xx -D__LPC13XX__ -I"/home/prometheus/Desktop/Renaux/Lib_EaBaseBoard/inc" -I"/home/prometheus/Desktop/Renaux/Lib_MCU/inc" -I"/home/prometheus/Desktop/Renaux/RTXLIB/inc" -I"/home/prometheus/Desktop/Renaux/CMSISv2p00_LPC13xx/inc" -Os -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"src/cr_startup_lpc13xx.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/RTX_Conf_CM.c \
../src/cr_startup_lpc13uxx.c \
../src/crp.c \
../src/main.c \
../src/system_ARMCM3.c 

OBJS += \
./src/RTX_Conf_CM.o \
./src/cr_startup_lpc13uxx.o \
./src/crp.o \
./src/main.o \
./src/system_ARMCM3.o 

C_DEPS += \
./src/RTX_Conf_CM.d \
./src/cr_startup_lpc13uxx.d \
./src/crp.d \
./src/main.d \
./src/system_ARMCM3.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p10_LPC13Uxx -D__LPC13UXX__ -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/LPC13Uxx_DriverLib/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/Lib_EaBaseBoard/inc" -include"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc/cmsis_os.h" -O0 -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/cr_startup_lpc13uxx.o: ../src/cr_startup_lpc13uxx.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p10_LPC13Uxx -D__LPC13UXX__ -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/LPC13Uxx_DriverLib/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/Lib_EaBaseBoard/inc" -include"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc/cmsis_os.h" -O0 -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"src/cr_startup_lpc13uxx.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/main.o: ../src/main.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DDEBUG -D__CODE_RED -DCORE_M3 -D__USE_CMSIS=CMSISv2p10_LPC13Uxx -D__LPC13UXX__ -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/LPC13Uxx_DriverLib/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/src" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc" -I"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/Lib_EaBaseBoard/inc" -include"/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/RTXLIB/inc/cmsis_os.h" -O0 -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=cortex-m3 -mthumb -MMD -MP -MF"$(@:%.o=%.d)" -MT"src/main.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lCMSISv2p10_LPC13Uxx -lRTXLIB -lLib_EaBaseBoard -lLPC13Uxx_DriverLib


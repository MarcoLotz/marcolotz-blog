src/system_LPC13Uxx.d: ../src/system_LPC13Uxx.c \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/LPC13Uxx.h \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cm3.h \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cmInstr.h \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cmFunc.h \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/system_LPC13Uxx.h

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/LPC13Uxx.h:

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cm3.h:

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cmInstr.h:

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/core_cmFunc.h:

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/CMSISv2p10_LPC13Uxx/inc/system_LPC13Uxx.h:

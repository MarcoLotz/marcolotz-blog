################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../src/GCC/HAL_CM3.s \
../src/GCC/SVC_Table.s 

OBJS += \
./src/GCC/HAL_CM3.o \
./src/GCC/SVC_Table.o 


# Each subdirectory must supply rules for building sources it contributes
src/GCC/%.o: ../src/GCC/%.s
	@echo 'Building file: $<'
	@echo 'Invoking: MCU Assembler'
	arm-none-eabi-gcc -c -x assembler-with-cpp -D__REDLIB__ -DDEBUG -D__CODE_RED -mcpu=cortex-m3 -mthumb -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



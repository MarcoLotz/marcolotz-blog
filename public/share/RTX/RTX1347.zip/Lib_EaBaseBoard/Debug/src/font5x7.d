src/font5x7.d: ../src/font5x7.c \
 /home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/Lib_EaBaseBoard/inc/font_macro.h

/home/prometheus/Dropbox/oitavoPeriodo2/embeddedSystems/lab/workspace/Lib_EaBaseBoard/inc/font_macro.h:
